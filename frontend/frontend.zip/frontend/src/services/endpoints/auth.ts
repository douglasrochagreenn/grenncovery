export const routes = {
  login: () => "auth/login",
  profile: () => "auth/profile",
};
