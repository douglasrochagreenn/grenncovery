<script setup lang="ts"></script>
<template>
  <div class="flex items-center h-dvh container md:flex-col md:top-20 relative md:gap-4">
    <div class="grid gap-4">
      <h1 class="text-yellow font-extrabold text-9xl text-[120px]">404</h1>
      <h2 class="text-primary text-3xl text-[32px] font-bold">Rota não encontrada!</h2>
      <div class="grid gap-4">
        <p class="text-[#808080] text-xl">
          Parece que você pegou um desvio errado e caiu em uma estrada sem saída. Mas não se preocupe, ainda dá para
          voltar ao caminho certo!
        </p>
        <p class="text-[#808080] text-xl">
          Enquanto isso, que tal explorar nossas melhores ofertas? O carro dos seus sonhos pode estar a um clique de
          distância!
        </p>
      </div>
    </div>
    <!-- <img src="@/assets/imgs/404.png" alt="404" width="642px" height="417px" /> -->
  </div>
</template>

<style scoped lang="scss"></style>
