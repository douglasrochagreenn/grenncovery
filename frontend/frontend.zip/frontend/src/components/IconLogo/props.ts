export interface IProps {
  variant?: "default" | "foreground" | "white" | "black";
}
