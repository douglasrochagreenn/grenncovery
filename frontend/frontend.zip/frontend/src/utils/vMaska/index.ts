export const phoneMaska = "+## (##) # ####-####";

export const cpfMaska = "###.###.###-##";

export const cepMaska = "#####-###";

export const cnpjMaska = "##.###.###/####-##";
