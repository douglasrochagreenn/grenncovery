export const routes = {
  get: (params: string) => `api/abandoned-carts?${params}`,
};
